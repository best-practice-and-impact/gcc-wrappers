# Code of conduct for `{{ cookiecutter.project_slug }}`

[Our code of conduct can be found at
`docs/contributor_guide/CODE_OF_CONDUCT.md`][code-of-conduct].

[code-of-conduct]: https://github.com/best-practice-and-impact/govcookiecutter/blob/main/%7B%7B%20cookiecutter.repo_name%20%7D%7D/docs/contributor_guide/CODE_OF_CONDUCT.md
