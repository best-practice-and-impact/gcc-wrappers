# `tests` folder overview

All tests for the functions defined in the `{{ cookiecutter.project_slug }}` folder should be stored here.
